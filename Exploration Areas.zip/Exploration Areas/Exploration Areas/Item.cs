﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exploration_Areas
{
    public class Item
    {
        public string Item_Name;
        public string Item_Description;
        public int Item_Power_Level
    }
}