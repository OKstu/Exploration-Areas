﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exploration_Areas
{
    public class Player_Info
    {
        public string Name;
        public int Experience_Points;
        public int Health_Points;
    }
}