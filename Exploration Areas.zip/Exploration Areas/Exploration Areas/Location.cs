﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exploration_Areas
{
    public class Location
    {
        private string Name;
        private string Description;
    }
}